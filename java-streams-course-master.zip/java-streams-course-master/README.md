# java-streams-course
## Simply open pom.xml using Intellij and run tests
